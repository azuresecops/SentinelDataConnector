import os
import logging
import requests
import json
from datetime import datetime
from hashlib import sha256
import hmac
import base64

import azure.functions as func

# Retrieve environment variables
workspace_id = os.getenv('WorkspaceID')
shared_key = os.getenv('WorkspaceKey')
bitdefender_api_token = os.getenv('BitdefenderAPIToken')
bitdefender_api_endpoint = os.getenv('BitdefenderAPIEndpoint')

# Log Analytics custom log type
log_type = 'BitdefenderGravityZone_CL'

def build_signature(date, content_length):
    """Build signature for Log Analytics API request."""
    string_to_hash = f"POST\n{content_length}\napplication/json\nx-ms-date:{date}\n/api/logs"
    decoded_shared_key = base64.b64decode(shared_key)
    hashed_string = hmac.new(
        decoded_shared_key,
        bytes(string_to_hash, encoding="utf-8"),
        digestmod=sha256,
    ).digest()
    signature = base64.b64encode(hashed_string).decode()
    return f"SharedKey {workspace_id}:{signature}"

def post_data_to_log_analytics(body):
    """Post data to Azure Log Analytics."""
    date = datetime.utcnow().strftime("%a, %d %b %Y %H:%M:%S GMT")
    body_json = json.dumps(body)
    content_length = len(body_json)
    signature = build_signature(date, content_length)
    
    uri = f"https://{workspace_id}.ods.opinsights.azure.com/api/logs?api-version=2016-04-01"
    
    headers = {
        "Content-Type": "application/json",
        "Authorization": signature,
        "Log-Type": log_type,
        "x-ms-date": date
    }
    
    response = requests.post(uri, data=body_json, headers=headers)
    
    if response.status_code >= 200 and response.status_code <= 299:
        logging.info("Logs successfully sent to Log Analytics.")
    else:
        logging.error(f"Failed to send logs. Response code: {response.status_code}, Response text: {response.text}")

def get_bitdefender_logs():
    """Retrieve logs from the Bitdefender GravityZone API."""
    headers = {
        "Authorization": f"Bearer {bitdefender_api_token}",
        "Content-Type": "application/json"
    }
    
    # Adjust API path according to the specific Bitdefender endpoint.
    url = f"{bitdefender_api_endpoint}/v1.0/logs"
    
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        logs = response.json()
        return logs
    else:
        logging.error(f"Failed to retrieve Bitdefender logs: {response.text}")
        return None

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')

    logs = get_bitdefender_logs()

    if logs:
        # Send logs to Log Analytics workspace
        post_data_to_log_analytics(logs)
        return func.HttpResponse("Logs successfully ingested into Log Analytics.", status_code=200)
    else:
        return func.HttpResponse("Failed to retrieve logs.", status_code=500)
